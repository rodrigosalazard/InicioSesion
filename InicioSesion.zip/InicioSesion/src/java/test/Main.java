/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import DAO.Sesion;
import controlador.SesionDaoHibernate;

/**
 *
 * @author Rodrigo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SesionDaoHibernate sesionDAO = new SesionDaoHibernate();
        Sesion sesion = new Sesion();
        sesion.setNombreusuario("pacoperez");
        sesion.setPassword("1234");
        sesionDAO.save(sesion);
        System.out.println("Todo salio bien en el insert");

    }
    
}
